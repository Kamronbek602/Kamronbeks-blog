const users = JSON.parse(localStorage.getItem("users") || "[]");

function checkLogin(btn) {
  const login = document.getElementById("login").value.trim();
  const password = document.getElementById("password").value.trim();
  const user = users.find(u => u.login === login && u.password === password);

  if (user) {
    localStorage.setItem("currentUser", JSON.stringify(user));
    if (!user.name) {
      window.location.href = "register.html";
    } else {
      window.location.href = "home.html";
    }
  } else {
    document.getElementById("login-error").textContent = "Login yoki parol noto‘g‘ri.";
    btn.classList.add("shake");
    setTimeout(() => btn.classList.remove("shake"), 300);
  }
}

function saveName() {
  const name = document.getElementById("name").value.trim();
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));
  if (!name) {
    document.getElementById("name-error").textContent = "Ismni kiriting.";
    return;
  }

  if (users.some(u => u.name === name && u.login !== currentUser.login)) {
    document.getElementById("name-error").textContent = "Bu ism allaqachon ishlatilgan.";
    return;
  }

  const updatedUsers = users.map(u => {
    if (u.login === currentUser.login) {
      u.name = name;
      return u;
    }
    return u;
  });

  localStorage.setItem("users", JSON.stringify(updatedUsers));
  localStorage.setItem("currentUser", JSON.stringify({ ...currentUser, name }));
  window.location.href = "home.html";
}

function setLang(lang) {
  localStorage.setItem("lang", lang);
  location.reload();
}
function toggleMode() {
  const body = document.body;
  const current = localStorage.getItem("mode") || "light";
  const next = current === "light" ? "dark" : "light";
  localStorage.setItem("mode", next);
  applyMode();
}

function applyMode() {
  const mode = localStorage.getItem("mode") || "light";
  document.body.className = mode === "dark" ? "dark-mode" : "";
}

applyMode();
